//
//  Constants.swift
//  lecture8
//
//  Created by admin on 09.02.2021.
//

import Foundation

struct Constants {
    static let host = "https://api.openweathermap.org/data/2.5/onecall?lat=51.1801&lon=71.446&exclude=minutely,alerts&appid=8003a79a17defb48c485513cba4e943d&units=metric"
    static let city = "Rudnyy"
    
    static let host1 = "https://api.openweathermap.org/data/2.5/onecall?lat=43.238949&lon=76.889709&exclude=minutely,alerts&appid=8003a79a17defb48c485513cba4e943d&units=metric"
    static let city1 = "Kostanay"
    
    static let host2 = "https://api.openweathermap.org/data/2.5/onecall?lat=52.3000&lon=76.9500&exclude=minutely,alerts&appid=8003a79a17defb48c485513cba4e943d&units=metric"
    let city2 = "Nur-Sultan"
    
    static let apiKey = "b9abbc89e2661b7fa9213885378f6b96"
}
